TotalFood <- read.csv("C:/Users/Mat/Documents/Spring 2020/myfoodapediadata/Food_Display_Table.csv")
ModFood <- read.csv("C:/Users/Mat/Documents/Spring 2020/myfoodapediadata/Food_Display_Table._Modcsv.csv")
Alcoholic <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Alcoholic.csv")
Beans_Nuts_Seeds <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Beans_Nuts_Seeds.csv")
Dairy <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Dairy.csv")
Eggs <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Eggs.csv")
Fish <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Fish.csv")
Fruit <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Fruit.csv")
Grain <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Grain.csv")
Meat <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Meat.csv")
NonAlcoholic <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Non-Alcoholic.csv")
Oils <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Oils.csv")
Sweets <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Sweets.csv")
Tofu <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Tofu.csv")
Vegetable <- read.csv("C:/Users/Mat/Documents/Spring 2020/DA FP/Vegetable.csv")

help('boxplot')
boxplot(Alcoholic$Calories, NonAlcoholic$Calorie, Beans_Nuts_Seeds$Calories,Eggs$Calories, Fish$Calories, Meat$Calories, Tofu$Calories, Fruit$Calories, Vegetable$Calories, Grain$Calories, Oils$Calories, Sweets$Calories)
boxplot()
boxplot()
boxplot()

boxplot(Alcoholic$Added_Sugars, NonAlcoholic$Added_Sugars)
boxplot(Beans_Nuts_Seeds$Added_Sugars,Eggs$Added_Sugars, Fish$Added_Sugars, Meat$Added_Sugars, Tofu$Added_Sugars)
boxplot(Fruit$Added_Sugars, Vegetable$Added_Sugars)
boxplot(Grain$Added_Sugars, Oils$Added_Sugars, Sweets$Added_Sugars)

boxplot(Alcoholic$Added_Sugars, NonAlcoholic$Added_Sugars)
boxplot(Beans_Nuts_Seeds$Added_Sugars,Eggs$Added_Sugars, Fish$Added_Sugars, Meat$Added_Sugars, Tofu$Added_Sugars)
boxplot(Fruit$Added_Sugars, Vegetable$Added_Sugars)
boxplot(Grain$Added_Sugars, Oils$Added_Sugars, Sweets$Added_Sugars)

boxplot(Alcoholic$Solid_Fats, NonAlcoholic$Solid_Fats)
boxplot(Beans_Nuts_Seeds$Solid_Fats,Eggs$Solid_Fats, Fish$Solid_Fats, Meat$Solid_Fats, Tofu$Solid_Fats)
boxplot(Fruit$Solid_Fats, Vegetable$Solid_Fats)
boxplot(Grain$Solid_Fats, Oils$Solid_Fats, Sweets$Solid_Fats)

boxplot(Alcoholic$Saturated_Fats, NonAlcoholic$Saturated_Fats)
boxplot(Beans_Nuts_Seeds$Saturated_Fats,Eggs$Saturated_Fats, Fish$Saturated_Fats, Meat$Saturated_Fats, Tofu$Saturated_Fats)
boxplot(Fruit$Saturated_Fats, Vegetable$Saturated_Fats)
boxplot(Grain$Saturated_Fats, Oils$Saturated_Fats, Sweets$Saturated_Fats)

qqplot(Alcoholic$Alcohol, Alcoholic$Calories)
qqplot(Alcoholic$Alcohol, Alcoholic$Added_Sugars)
qqplot(Alcoholic$Alcohol, Alcoholic$Solid_Fats)
qqplot(Alcoholic$Alcohol, Alcoholic$Saturated_Fats)

qqplot(Beans_Nuts_Seeds$Meats, Beans_Nuts_Seeds$Calories)
qqplot(Beans_Nuts_Seeds$Meats, Beans_Nuts_Seeds$Added_Sugars)
qqplot(Beans_Nuts_Seeds$Meats, Beans_Nuts_Seeds$Solid_Fats)
qqplot(Beans_Nuts_Seeds$Meats, Beans_Nuts_Seeds$Saturated_Fats)

qqplot(Beans_Nuts_Seeds$Drybeans_Peas, Beans_Nuts_Seeds$Calories)
qqplot(Beans_Nuts_Seeds$Drybeans_Peas, Beans_Nuts_Seeds$Added_Sugars)
qqplot(Beans_Nuts_Seeds$Drybeans_Peas, Beans_Nuts_Seeds$Solid_Fats)
qqplot(Beans_Nuts_Seeds$Drybeans_Peas, Beans_Nuts_Seeds$Saturated_Fats)

qqplot(Dairy$Milk, Dairy$Calories)
qqplot(Dairy$Milk, Dairy$Added_Sugars)
qqplot(Dairy$Milk, Dairy$Solid_Fats)
qqplot(Dairy$Milk, Dairy$Saturated_Fats)

qqplot(Eggs$Meats, Eggs$Calories)
qqplot(Eggs$Meats, Eggs$Added_Sugars)
qqplot(Eggs$Meats, Eggs$Solid_Fats)
qqplot(Eggs$Meats, Eggs$Saturated_Fats)

qqplot(Fish$Meats, Fish$Calories)
qqplot(Fish$Meats, Fish$Added_Sugars)
qqplot(Fish$Meats, Fish$Solid_Fats)
qqplot(Fish$Meats, Fish$Saturated_Fats)

qqplot(Fruit$Fruits, Fruit$Calories)
qqplot(Fruit$Fruits, Fruit$Added_Sugars)
qqplot(Fruit$Fruits, Fruit$Solid_Fats)
qqplot(Fruit$Fruits, Fruit$Saturated_Fats)

qqplot(Grain$Grains, Grain$Calories)
qqplot(Grain$Grains, Grain$Added_Sugars)
qqplot(Grain$Grains, Grain$Solid_Fats)
qqplot(Grain$Grains, Grain$Saturated_Fats)

qqplot(Meat$Meats, Meat$Calories)
qqplot(Meat$Meats, Meat$Added_Sugars)
qqplot(Meat$Meats, Meat$Solid_Fats)
qqplot(Meat$Meats, Meat$Saturated_Fats)

qqplot(NonAlcoholic$Fruits, NonAlcoholic$Calories)
qqplot(NonAlcoholic$Fruits, NonAlcoholic$Added_Sugars)
qqplot(NonAlcoholic$Fruits, NonAlcoholic$Solid_Fats)
qqplot(NonAlcoholic$Fruits, NonAlcoholic$Saturated_Fats)

qqplot(Oils$Oils, Oils$Calories)
qqplot(Oils$Oils, Oils$Added_Sugars)
qqplot(Oils$Oils, Oils$Solid_Fats)
qqplot(Oils$Oils, Oils$Saturated_Fats)

qqplot(Sweets$Grains, Sweets$Calories)
qqplot(Sweets$Grains, Sweets$Added_Sugars)
qqplot(Sweets$Grains, Sweets$Solid_Fats)
qqplot(Sweets$Grains, Sweets$Saturated_Fats)

qqplot(Tofu$Soy, Tofu$Calories)
qqplot(Tofu$Soy, Tofu$Added_Sugars)
qqplot(Tofu$Soy, Tofu$Solid_Fats)
qqplot(Tofu$Soy, Tofu$Saturated_Fats)

qqplot(Vegetable$Vegetable, Vegetable$Calories)
qqplot(Vegetable$Vegetable, Vegetable$Added_Sugars)
qqplot(Vegetable$Vegetable, Vegetable$Solid_Fats)
qqplot(Vegetable$Vegetable, Vegetable$Saturated_Fats)

help("ggplot")
ggplot(ModFood, aes(x = ModFood$Food_Type, y= ModFood$Calories, color=ModFood$Food_Type)) + geom_boxplot() + coord_flip() + xlab("Food Type") + ylab("Calorie Amount Per Servering")
ggplot(ModFood, aes(x = ModFood$Food_Type, y= ModFood$Added_Sugars, color=ModFood$Food_Type)) + geom_boxplot() + coord_flip() + xlab("Food Type") + ylab("Added Sugar Per Servering")
ggplot(ModFood, aes(x = ModFood$Food_Type, y= ModFood$Solid_Fats, color=ModFood$Food_Type)) + geom_boxplot() + coord_flip() + xlab("Food Type") + ylab("Solid Fats Per Servering")
ggplot(ModFood) + geom_histogram(aes(x=ModFood$Calories))+ facet_wrap(~ ModFood$Food_Type) + xlab("Calorie Amount Per Servering") + ylab("Amount of Food Items")
ggplot(ModFood) + geom_histogram(aes(x=ModFood$Added_Sugars))+ facet_wrap(~ ModFood$Food_Type) + xlab("Added Sugar Per Servering") + ylab("Amount of Food Items")
ggplot(ModFood) + geom_histogram(aes(x=ModFood$Solid_Fats))+ facet_wrap(~ ModFood$Food_Type) + xlab("Solid Fats Per Servering") + ylab("Amount of Food Items")
#Clustering Analysis & Descision Trees
#Add EDA Part to Poster

help('sample')
#Descision Tree
library(rpart)
library(rpart.plot)
s_Total <- sample(2000, 1400)
Total_train <- TotalFood[s_Total,]
Total_test <- TotalFood[-s_Total,]
dim(Total_train)
dim(Total_test)
calorieTreeModel <- rpart(Calories~Grains+Vegetables+Fruits+Milk+Meats+Oils, Total_train,
                          method = "anova")
rpart.plot(calorieTreeModel)
fatTreeModel <- rpart(Solid_Fats~Grains+Vegetables+Fruits+Milk+Meats+Oils, Total_train,
                          method = "anova")
rpart.plot(fatTreeModel)
sugarTreeModel <- rpart(Added_Sugars~Grains+Vegetables+Fruits+Milk+Meats+Oils, Total_train,
                      method = "anova")
rpart.plot(sugarTreeModel)

library(ggplot2)
#Clustering
plot1 <- ggplot(ModFood, aes(ModFood$Meats,ModFood$Calories))
print(plot1 + geom_point(size=3))
set.seed(101)
calorieClusters <- kmeans(ModFood$Calories, 5, nstart = 10) # nstart is the number of random start
sugarClusters <- kmeans(ModFood$Added_Sugars, 5, nstart = 10) # nstart is the number of random start
fatClusters <- kmeans(ModFood$Solid_Fats, 5, nstart = 10) # nstart is the number of random start
print(calorieClusters)
print(sugarClusters)
print(fatClusters)
table(calorieClusters$cluster,ModFood$Food_Type)
table(sugarClusters$cluster,ModFood$Food_Type)
table(fatClusters$cluster,ModFood$Food_Type)
library(cluster)
clusplot(ModFood,calorieClusters$cluster, color = TRUE, shade = TRUE, labels = 0, lines = 0)
clusplot(ModFood,sugarClusters$cluster, color = TRUE, shade = TRUE, labels = 0, lines = 0)
clusplot(ModFood,fatClusters$cluster, color = TRUE, shade = TRUE, labels = 0, lines = 0)
help("clusplot")
library(fpc)
vcol <- c("blue","green","yellow","orange","red")
plotcluster(ModFood$Food_Type, calorieClusters$cluster, col=vcol[calorieClusters$cluster])
plotcluster(ModFood$Food_Type, sugarClusters$cluster, col=vcol[sugarClusters$cluster])
plotcluster(ModFood$Food_Type, fatClusters$cluster, col=vcol[fatClusters$cluster])
help('plotcluster')
